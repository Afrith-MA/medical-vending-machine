const BASE = '/api';

async function request(path, options = {}) {
  const response = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json' },
    ...options,
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  const text = await response.text();
  const data = text ? JSON.parse(text) : null;

  if (!response.ok) {
    const error = new Error(data?.error?.message || `Request failed (${response.status})`);
    error.code = data?.error?.code;
    error.details = data?.error?.details;
    error.status = response.status;
    throw error;
  }
  return data;
}

export const api = {
  health: () => request('/health'),
  categories: () => request('/categories'),

  products: ({ category, q, sort } = {}) => {
    const params = new URLSearchParams();
    if (category) params.set('category', category);
    if (q) params.set('q', q);
    if (sort) params.set('sort', sort);
    const query = params.toString();
    return request(`/products${query ? `?${query}` : ''}`);
  },
  product: (id) => request(`/products/${id}`),

  validateCart: (items) => request('/cart/validate', { method: 'POST', body: { items } }),

  createOrder: (items, customerPhone) =>
    request('/orders', {
      method: 'POST',
      body: { items, customer_phone: customerPhone || undefined },
    }),
  order: (id) => request(`/orders/${id}`),
  cancelOrder: (id) => request(`/orders/${id}/cancel`, { method: 'POST' }),

  // Demo only — a real system confirms payment server-side from the provider.
  simulatePayment: (id, outcome) =>
    request(`/orders/${id}/simulate-payment`, { method: 'POST', body: { outcome } }),

  dispense: (id) => request(`/orders/${id}/dispense`, { method: 'POST' }),

  admin: {
    products: () => request('/admin/products'),
    updateProduct: (id, patch) =>
      request(`/admin/products/${id}`, { method: 'POST', body: patch }),
    restock: (id, quantity) =>
      request(`/admin/products/${id}/restock`, { method: 'POST', body: { quantity } }),
    orders: () => request('/admin/orders'),
    report: () => request('/admin/report'),
    reset: () => request('/admin/reset', { method: 'POST' }),
  },
};

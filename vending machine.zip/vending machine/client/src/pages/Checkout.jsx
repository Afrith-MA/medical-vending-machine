import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { useCart } from '../cart.js';
import { formatINR } from '../lib/format.js';
import ProductImage from '../lib/ProductImage.jsx';

export default function Checkout() {
  const navigate = useNavigate();
  const { items, lines, clear } = useCart();

  const [validated, setValidated] = useState(null);
  const [phone, setPhone] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState(null);

  // The server re-prices the cart and re-checks stock, expiry and recalls.
  // Anything it changed is shown to the user before they pay.
  useEffect(() => {
    if (items.length === 0) {
      setValidated(null);
      return;
    }
    api
      .validateCart(lines())
      .then(setValidated)
      .catch((err) => setError(err.message));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [items.length]);

  async function placeOrder() {
    setSubmitting(true);
    setError(null);
    try {
      const order = await api.createOrder(lines(), phone);
      clear();
      navigate(`/order/${order.id}`);
    } catch (err) {
      setError(err.message);
      setSubmitting(false);
    }
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-md px-4 py-24 text-center">
        <h1 className="text-xl font-semibold text-slate-900">Your cart is empty</h1>
        <p className="mt-2 text-sm text-slate-600">Add a product before checking out.</p>
        <Link to="/" className="btn-primary mt-6">
          Browse products
        </Link>
      </div>
    );
  }

  const cart = validated;

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <h1 className="text-2xl font-bold text-slate-900">Checkout</h1>
      <p className="mt-1 text-sm text-slate-600">
        Review your order, then pay by scanning the UPI QR code on the next screen.
      </p>

      {error && (
        <div className="mt-5 rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-800">
          {error}
        </div>
      )}

      {cart?.notices?.length > 0 && (
        <div className="mt-5 rounded-lg border border-amber-200 bg-amber-50 p-4">
          <h2 className="text-sm font-semibold text-amber-900">We adjusted your cart</h2>
          <ul className="mt-2 space-y-1 text-sm text-amber-900">
            {cart.notices.map((notice, index) => (
              <li key={index}>
                <span className="font-medium">{notice.product_name || notice.product_id}:</span>{' '}
                {notice.message}
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="mt-6 grid gap-6 md:grid-cols-[1fr_320px]">
        <div className="card divide-y divide-slate-100">
          {(cart?.items || items).map((item) => {
            const name = item.product_name || item.name;
            const quantity = item.quantity;
            const unit = item.unit_price_paise ?? item.price_paise;
            return (
              <div key={item.product_id} className="flex gap-4 p-4">
                <ProductImage product={item} className="h-16 w-16 shrink-0 rounded-lg" />
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-semibold text-slate-900">{name}</p>
                  <p className="text-xs text-slate-500">{item.pack_size}</p>
                  <p className="mt-1 text-xs text-slate-600">
                    {quantity} × {formatINR(unit)}
                    {item.slot_code && (
                      <span className="ml-2 font-mono text-slate-400">slot {item.slot_code}</span>
                    )}
                  </p>
                </div>
                <p className="text-sm font-semibold tabular-nums text-slate-900">
                  {formatINR(unit * quantity)}
                </p>
              </div>
            );
          })}
        </div>

        <div className="md:sticky md:top-24 md:self-start">
          <div className="card p-5">
            <h2 className="text-sm font-semibold text-slate-900">Order summary</h2>

            <dl className="mt-4 space-y-2 text-sm">
              <div className="flex justify-between">
                <dt className="text-slate-600">Items</dt>
                <dd className="tabular-nums">{cart?.item_count ?? '—'}</dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-600">Subtotal</dt>
                <dd className="tabular-nums">
                  {cart ? formatINR(cart.subtotal_paise) : '—'}
                </dd>
              </div>
              <div className="flex justify-between">
                <dt className="text-slate-600">GST (included)</dt>
                <dd className="tabular-nums">{cart ? formatINR(cart.tax_paise) : '—'}</dd>
              </div>
              <div className="flex justify-between border-t border-slate-200 pt-3 text-base font-bold">
                <dt>Total</dt>
                <dd className="tabular-nums">{cart ? formatINR(cart.total_paise) : '—'}</dd>
              </div>
            </dl>

            <div className="mt-5">
              <label htmlFor="phone" className="text-sm font-medium text-slate-700">
                Mobile number <span className="font-normal text-slate-400">(optional)</span>
              </label>
              <input
                id="phone"
                type="tel"
                inputMode="numeric"
                maxLength={10}
                value={phone}
                onChange={(event) => setPhone(event.target.value.replace(/\D/g, ''))}
                placeholder="10-digit number"
                className="field mt-1.5"
              />
              <p className="mt-1.5 text-xs text-slate-500">
                Used only to look up this order if collection fails.
              </p>
            </div>

            <button
              type="button"
              className="btn-primary mt-5 w-full"
              disabled={!cart || cart.items.length === 0 || submitting}
              onClick={placeOrder}
            >
              {submitting ? 'Creating order…' : `Pay ${cart ? formatINR(cart.total_paise) : ''}`}
            </button>

            <p className="mt-3 text-xs leading-relaxed text-slate-500">
              Read the label before use. Consult a qualified healthcare professional if you are
              unsure whether a product is suitable for you.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '../api.js';
import { formatDateTime, formatINR } from '../lib/format.js';

const STEPS = [
  { key: 'pay', label: 'Pay' },
  { key: 'dispense', label: 'Dispense' },
  { key: 'collect', label: 'Collect' },
];

function stepIndex(status) {
  if (['awaiting_payment', 'payment_failed', 'cancelled'].includes(status)) return 0;
  if (['paid', 'dispensing'].includes(status)) return 1;
  return 2;
}

function Stepper({ status }) {
  const current = stepIndex(status);
  return (
    <ol className="flex items-center gap-2 no-print">
      {STEPS.map((step, index) => (
        <li key={step.key} className="flex flex-1 items-center gap-2">
          <span
            className={`grid h-7 w-7 shrink-0 place-items-center rounded-full text-xs font-bold ${
              index < current
                ? 'bg-vital-600 text-white'
                : index === current
                  ? 'bg-medical-600 text-white'
                  : 'bg-slate-200 text-slate-500'
            }`}
          >
            {index < current ? '✓' : index + 1}
          </span>
          <span
            className={`text-sm font-medium ${
              index <= current ? 'text-slate-900' : 'text-slate-400'
            }`}
          >
            {step.label}
          </span>
          {index < STEPS.length - 1 && (
            <span
              className={`hidden h-px flex-1 sm:block ${
                index < current ? 'bg-vital-400' : 'bg-slate-200'
              }`}
            />
          )}
        </li>
      ))}
    </ol>
  );
}

/* -------------------------------------------------------------- pay screen */

function PaymentScreen({ order, onSimulate, busy }) {
  const [elapsed, setElapsed] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => setElapsed((value) => value + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  const minutes = String(Math.floor(elapsed / 60)).padStart(2, '0');
  const seconds = String(elapsed % 60).padStart(2, '0');

  return (
    <div className="grid gap-6 md:grid-cols-[320px_1fr]">
      <div className="card p-5 text-center">
        <h2 className="text-sm font-semibold text-slate-900">Scan to pay</h2>
        <p className="mt-1 text-xs text-slate-500">Use any UPI app</p>

        <div className="relative mx-auto mt-4 w-fit">
          <img
            src={order.qr_data_url}
            alt={`UPI QR code for order ${order.id}`}
            className="h-56 w-56 rounded-lg border border-slate-200"
          />
          <span className="absolute -right-2 -top-2 rounded-full bg-amber-500 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide text-white">
            Demo
          </span>
        </div>

        <p className="mt-4 text-2xl font-bold tabular-nums text-slate-900">
          {formatINR(order.total_paise)}
        </p>
        <p className="mt-1 font-mono text-xs text-slate-500">{order.id}</p>
        <p className="mt-3 text-xs text-slate-400">Waiting for payment · {minutes}:{seconds}</p>

        <a
          href={order.upi_intent_url}
          className="btn-ghost mt-4 w-full text-xs"
          title="Opens a UPI app on a mobile device"
        >
          Open in UPI app
        </a>
      </div>

      <div>
        <div className="rounded-lg border border-amber-300 bg-amber-50 p-5">
          <h2 className="flex items-center gap-2 text-sm font-bold text-amber-900">
            <span className="rounded bg-amber-500 px-1.5 py-0.5 text-[10px] uppercase tracking-wide text-white">
              Simulation
            </span>
            No real payment is taken
          </h2>
          <p className="mt-2 text-sm leading-relaxed text-amber-900">
            The QR code above is a genuine UPI payment link, but this prototype is not connected to
            a payment provider, so nothing can confirm a real transfer. Use the buttons below to
            simulate what the provider would tell the server.
          </p>
          <p className="mt-2 text-xs leading-relaxed text-amber-800">
            In a real deployment these buttons would not exist: the server would be told the payment
            succeeded by a signed webhook from the payment provider, or by polling the provider's
            API — never by the browser.
          </p>

          <div className="mt-4 flex flex-col gap-2 sm:flex-row">
            <button
              type="button"
              className="btn-success flex-1"
              disabled={busy}
              onClick={() => onSimulate('success')}
            >
              {busy ? 'Working…' : 'Simulate payment received'}
            </button>
            <button
              type="button"
              className="btn-danger flex-1"
              disabled={busy}
              onClick={() => onSimulate('failure')}
            >
              Simulate payment failure
            </button>
          </div>
        </div>

        <div className="card mt-5 p-5">
          <h3 className="text-sm font-semibold text-slate-900">In this order</h3>
          <ul className="mt-3 divide-y divide-slate-100">
            {order.items.map((item) => (
              <li key={item.product_id} className="flex justify-between gap-4 py-2.5 text-sm">
                <span className="min-w-0">
                  <span className="block truncate font-medium text-slate-800">
                    {item.product_name}
                  </span>
                  <span className="text-xs text-slate-500">
                    {item.quantity} × {formatINR(item.unit_price_paise)} · slot{' '}
                    <span className="font-mono">{item.slot_code}</span>
                  </span>
                </span>
                <span className="shrink-0 font-semibold tabular-nums">
                  {formatINR(item.line_total_paise)}
                </span>
              </li>
            ))}
          </ul>
          <div className="mt-3 flex justify-between border-t border-slate-200 pt-3 text-base font-bold">
            <span>Total</span>
            <span className="tabular-nums">{formatINR(order.total_paise)}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

/* --------------------------------------------------------- dispensing view */

function DispensingScreen({ order }) {
  return (
    <div className="card p-10 text-center">
      <div className="relative mx-auto h-20 w-20">
        <span className="absolute inset-0 animate-pulse-ring rounded-full bg-medical-400" />
        <span className="relative grid h-20 w-20 place-items-center rounded-full bg-medical-600 text-white">
          <svg viewBox="0 0 24 24" className="h-9 w-9" fill="currentColor" aria-hidden="true">
            <path d="M12 2 4 6v6c0 5 3.4 9.4 8 10 4.6-.6 8-5 8-10V6l-8-4Zm0 5 1.5 3.2 3.5.4-2.6 2.4.7 3.5L12 14.8 8.9 16.5l.7-3.5L7 10.6l3.5-.4L12 7Z" />
          </svg>
        </span>
      </div>

      <h2 className="mt-6 text-xl font-bold text-slate-900">Dispensing your items…</h2>
      <p className="mt-2 text-sm text-slate-600">
        Please wait at the collection tray. Do not shake the machine.
      </p>

      <ul className="mx-auto mt-6 max-w-sm space-y-2 text-left">
        {order.items.map((item) => (
          <li
            key={item.product_id}
            className="flex items-center justify-between rounded-lg bg-slate-50 px-4 py-2.5 text-sm"
          >
            <span className="truncate text-slate-700">{item.product_name}</span>
            <span className="ml-3 shrink-0 font-mono text-xs text-slate-500">
              slot {item.slot_code}
            </span>
          </li>
        ))}
      </ul>

      <p className="mt-6 text-xs text-amber-700">
        Simulated dispensing — no physical machine is attached.
      </p>
    </div>
  );
}

/* ------------------------------------------------------------ result views */

function ResultScreen({ order }) {
  const dispensed = order.items.filter((item) => item.dispensed_quantity > 0);
  const failed = order.items.filter((item) => item.dispensed_quantity === 0);
  const allGood = order.status === 'dispensed';

  return (
    <div className="space-y-6">
      <div
        className={`card p-6 text-center ${
          allGood ? 'border-vital-300 bg-vital-50' : 'border-amber-300 bg-amber-50'
        }`}
      >
        <span
          className={`mx-auto grid h-14 w-14 place-items-center rounded-full text-2xl text-white ${
            allGood ? 'bg-vital-600' : 'bg-amber-500'
          }`}
        >
          {allGood ? '✓' : '!'}
        </span>
        <h2
          className={`mt-4 text-xl font-bold ${allGood ? 'text-vital-900' : 'text-amber-900'}`}
        >
          {allGood
            ? 'Product Dispensed Successfully'
            : order.status === 'partially_dispensed'
              ? 'Partially dispensed'
              : 'Dispensing failed'}
        </h2>
        <p className={`mt-1.5 text-sm ${allGood ? 'text-vital-800' : 'text-amber-900'}`}>
          {allGood
            ? 'Please collect your items from the tray below.'
            : 'Some items could not be released by the machine.'}
        </p>
      </div>

      {dispensed.length > 0 && (
        <div className="card p-5">
          <h3 className="text-sm font-semibold text-slate-900">Collect from these slots</h3>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            {dispensed.map((item) => (
              <div
                key={item.product_id}
                className="flex items-center gap-3 rounded-lg border border-vital-200 bg-vital-50 p-3"
              >
                <span className="grid h-12 w-12 shrink-0 place-items-center rounded-lg bg-vital-600 font-mono text-lg font-bold text-white">
                  {item.slot_code}
                </span>
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-slate-900">
                    {item.product_name}
                  </p>
                  <p className="text-xs text-slate-600">
                    {item.dispensed_quantity} × {item.pack_size}
                  </p>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-4 rounded-lg bg-slate-100 p-3 text-center">
            <p className="text-xs uppercase tracking-wide text-slate-500">Collection code</p>
            <p className="mt-0.5 font-mono text-xl font-bold tracking-[0.2em] text-slate-900">
              {order.collection_code}
            </p>
            <p className="mt-1 text-xs text-slate-500">
              Quote this code if you need to contact support about this order.
            </p>
          </div>
        </div>
      )}

      {failed.length > 0 && (
        <div className="card border-rose-200 p-5">
          <h3 className="text-sm font-semibold text-rose-900">Could not be dispensed</h3>
          <ul className="mt-2.5 space-y-1.5 text-sm text-slate-700">
            {failed.map((item) => (
              <li key={item.product_id} className="flex justify-between gap-3">
                <span>
                  {item.product_name}{' '}
                  <span className="font-mono text-xs text-slate-500">({item.slot_code})</span>
                </span>
                <span className="tabular-nums">{formatINR(item.line_total_paise)}</span>
              </li>
            ))}
          </ul>

          {order.refund_status === 'initiated' && (
            <div className="mt-4 rounded-lg bg-rose-50 p-3 text-sm text-rose-900">
              <p className="font-semibold">
                Refund of {formatINR(order.refund_amount_paise)} initiated
              </p>
              <p className="mt-1 text-xs">
                Reference <span className="font-mono">{order.refund_reference}</span>. In a real
                deployment this would be returned to the source account within 5–7 working days.
              </p>
            </div>
          )}

          <p className="mt-3 text-xs text-slate-600">
            Do not shake or tilt the machine. Call the helpline on 1800-000-0000 and quote order{' '}
            <span className="font-mono">{order.id}</span>.
          </p>
        </div>
      )}

      {/* ------------------------------------------------------- receipt */}
      <div className="card p-5">
        <div className="flex items-start justify-between">
          <h3 className="text-sm font-semibold text-slate-900">Receipt</h3>
          <button type="button" className="btn-ghost px-3 py-1.5 text-xs no-print" onClick={() => window.print()}>
            Print
          </button>
        </div>

        <dl className="mt-3 grid gap-x-6 gap-y-2 text-sm sm:grid-cols-2">
          {[
            ['Order ID', order.id],
            ['Machine', order.machine_id],
            ['Placed', formatDateTime(order.created_at)],
            ['Paid', formatDateTime(order.paid_at)],
            ['Payment reference', order.payment?.reference || '—'],
            ['Status', order.status.replace(/_/g, ' ')],
          ].map(([label, value]) => (
            <div key={label} className="flex justify-between gap-3 sm:block">
              <dt className="text-xs uppercase tracking-wide text-slate-400">{label}</dt>
              <dd className="font-mono text-slate-800 sm:mt-0.5">{value}</dd>
            </div>
          ))}
        </dl>

        <table className="mt-4 w-full text-sm">
          <thead>
            <tr className="border-b border-slate-200 text-left text-xs uppercase tracking-wide text-slate-400">
              <th className="pb-2 font-medium">Item</th>
              <th className="pb-2 text-center font-medium">Qty</th>
              <th className="pb-2 text-right font-medium">Amount</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {order.items.map((item) => (
              <tr key={item.product_id}>
                <td className="py-2">
                  <span className="block text-slate-800">{item.product_name}</span>
                  <span className="text-xs text-slate-500">{item.pack_size}</span>
                </td>
                <td className="py-2 text-center tabular-nums">{item.quantity}</td>
                <td className="py-2 text-right tabular-nums">
                  {formatINR(item.line_total_paise)}
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="border-t border-slate-200 text-slate-600">
              <td className="pt-2 text-xs" colSpan={2}>
                GST (included)
              </td>
              <td className="pt-2 text-right text-xs tabular-nums">
                {formatINR(order.tax_paise)}
              </td>
            </tr>
            <tr className="font-bold">
              <td className="pt-1" colSpan={2}>
                Total paid
              </td>
              <td className="pt-1 text-right tabular-nums">{formatINR(order.total_paise)}</td>
            </tr>
            {order.refund_amount_paise > 0 && (
              <tr className="text-rose-700">
                <td className="pt-1" colSpan={2}>
                  Refund initiated
                </td>
                <td className="pt-1 text-right tabular-nums">
                  −{formatINR(order.refund_amount_paise)}
                </td>
              </tr>
            )}
          </tfoot>
        </table>

        <p className="mt-4 border-t border-slate-200 pt-3 text-xs leading-relaxed text-slate-500">
          Simulated transaction — no money was taken. Read the label before use and consult a
          qualified healthcare professional if you are unsure whether a product is suitable for you.
        </p>
      </div>

      <div className="flex gap-3 no-print">
        <Link to="/" className="btn-primary flex-1 justify-center">
          Buy something else
        </Link>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ page */

export default function Order() {
  const { id } = useParams();
  const [order, setOrder] = useState(null);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState(false);
  const dispenseStarted = useRef(false);

  const load = useCallback(async () => {
    try {
      setOrder(await api.order(id));
    } catch (err) {
      setError(err.message);
    }
  }, [id]);

  useEffect(() => {
    load();
  }, [load]);

  // Once the server says the order is paid, ask it to dispense. Guarded so a
  // re-render cannot trigger a second run; the endpoint is idempotent anyway.
  useEffect(() => {
    if (order?.status !== 'paid' || dispenseStarted.current) return;
    dispenseStarted.current = true;
    setOrder({ ...order, status: 'dispensing' });
    api
      .dispense(order.id)
      .then(setOrder)
      .catch((err) => setError(err.message));
  }, [order]);

  async function simulate(outcome) {
    setBusy(true);
    try {
      setOrder(await api.simulatePayment(id, outcome));
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  if (error) {
    return (
      <div className="mx-auto max-w-md px-4 py-24 text-center">
        <h1 className="text-lg font-semibold text-slate-900">{error}</h1>
        <Link to="/" className="btn-primary mt-6">
          Back to products
        </Link>
      </div>
    );
  }

  if (!order) {
    return (
      <div className="mx-auto max-w-4xl px-4 py-10 sm:px-6">
        <div className="h-80 animate-pulse rounded-xl bg-slate-100" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-8 sm:px-6">
      <div className="mb-6 no-print">
        <Stepper status={order.status} />
      </div>

      {order.status === 'awaiting_payment' && (
        <PaymentScreen order={order} onSimulate={simulate} busy={busy} />
      )}

      {order.status === 'payment_failed' && (
        <div className="card border-rose-200 p-10 text-center">
          <span className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-rose-600 text-2xl text-white">
            ✕
          </span>
          <h2 className="mt-4 text-xl font-bold text-rose-900">Payment not completed</h2>
          <p className="mt-2 text-sm text-slate-600">
            Nothing was charged and the items have been returned to the machine.
          </p>
          <Link to="/" className="btn-primary mt-6">
            Start again
          </Link>
        </div>
      )}

      {['paid', 'dispensing'].includes(order.status) && <DispensingScreen order={order} />}

      {['dispensed', 'partially_dispensed', 'dispense_failed'].includes(order.status) && (
        <ResultScreen order={order} />
      )}

      {order.status === 'cancelled' && (
        <div className="card p-10 text-center">
          <h2 className="text-lg font-semibold text-slate-900">Order cancelled</h2>
          <Link to="/" className="btn-primary mt-6">
            Back to products
          </Link>
        </div>
      )}
    </div>
  );
}

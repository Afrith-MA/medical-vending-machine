import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import { useCart } from '../cart.js';
import { formatINR } from '../lib/format.js';
import ProductImage from '../lib/ProductImage.jsx';

function ProductCard({ product }) {
  const add = useCart((state) => state.add);
  const [added, setAdded] = useState(false);
  const low = product.stock > 0 && product.stock <= 3;

  function handleAdd() {
    add(product, 1);
    setAdded(true);
    setTimeout(() => setAdded(false), 1200);
  }

  return (
    <article className="card flex flex-col overflow-hidden transition-shadow hover:shadow-card-hover">
      <Link to={`/product/${product.id}`} className="block bg-slate-50/60 p-4">
        <ProductImage product={product} className="mx-auto h-32 w-32" />
      </Link>

      <div className="flex flex-1 flex-col p-4 pt-3">
        <div className="flex items-start justify-between gap-2">
          <h3 className="text-sm font-semibold leading-snug text-slate-900">
            <Link to={`/product/${product.id}`} className="hover:text-medical-700">
              {product.name}
            </Link>
          </h3>
          <span className="pill shrink-0 bg-slate-100 font-mono text-slate-600">
            {product.slot_code}
          </span>
        </div>

        <p className="mt-0.5 text-xs text-slate-500">{product.pack_size}</p>
        <p className="mt-2 line-clamp-2 text-xs leading-relaxed text-slate-600">
          {product.uses[0]}
        </p>

        <div className="mt-3 flex items-center gap-2">
          <span className={`pill ${low ? 'bg-amber-100 text-amber-800' : 'bg-vital-100 text-vital-800'}`}>
            {low ? `Only ${product.stock} left` : `${product.stock} in machine`}
          </span>
          {product.warnings?.length > 0 && (
            <span className="pill bg-rose-50 text-rose-700">Read warnings</span>
          )}
        </div>

        <div className="mt-auto flex items-end justify-between gap-2 pt-4">
          <div>
            <p className="text-lg font-bold leading-none tabular-nums text-slate-900">
              {formatINR(product.price_paise)}
            </p>
            {product.mrp_paise > product.price_paise && (
              <p className="mt-1 text-xs text-slate-400 line-through tabular-nums">
                {formatINR(product.mrp_paise)}
              </p>
            )}
          </div>
          <div className="flex gap-1.5">
            <Link to={`/product/${product.id}`} className="btn-ghost px-3 py-2 text-xs">
              Details
            </Link>
            <button
              type="button"
              onClick={handleAdd}
              disabled={product.max_purchasable <= 0}
              className={`${added ? 'btn-success' : 'btn-primary'} px-3 py-2 text-xs`}
            >
              {added ? 'Added ✓' : 'Add'}
            </button>
          </div>
        </div>
      </div>
    </article>
  );
}

function CategoryTabs({ categories, active, onSelect }) {
  return (
    <div className="-mx-4 overflow-x-auto px-4 sm:mx-0 sm:px-0">
      <div className="flex gap-2 pb-1">
        <button
          type="button"
          onClick={() => onSelect('')}
          className={`shrink-0 rounded-full border px-4 py-2 text-sm font-medium transition-colors ${
            active === ''
              ? 'border-medical-600 bg-medical-600 text-white'
              : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
          }`}
        >
          All products
        </button>
        {categories.map((category) => (
          <button
            key={category.key}
            type="button"
            onClick={() => onSelect(category.key)}
            className={`shrink-0 rounded-full border px-4 py-2 text-sm font-medium transition-colors ${
              active === category.key
                ? 'border-medical-600 bg-medical-600 text-white'
                : 'border-slate-300 bg-white text-slate-700 hover:bg-slate-50'
            }`}
          >
            {category.label}
            <span
              className={`ml-1.5 text-xs ${
                active === category.key ? 'text-medical-100' : 'text-slate-400'
              }`}
            >
              {category.product_count}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

export default function Home() {
  const [categories, setCategories] = useState([]);
  const [products, setProducts] = useState([]);
  const [category, setCategory] = useState('');
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');
  const [sort, setSort] = useState('name_asc');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    api.categories().then(setCategories).catch(() => {});
  }, []);

  // Debounce the search box so typing doesn't fire a request per keystroke.
  useEffect(() => {
    const timer = setTimeout(() => setQuery(search), 250);
    return () => clearTimeout(timer);
  }, [search]);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    api
      .products({ category, q: query, sort })
      .then((rows) => {
        if (!cancelled) {
          setProducts(rows);
          setError(null);
        }
      })
      .catch((err) => !cancelled && setError(err.message))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [category, query, sort]);

  const activeCategory = useMemo(
    () => categories.find((entry) => entry.key === category),
    [categories, category],
  );

  return (
    <>
      <section className="border-b border-slate-200 bg-gradient-to-b from-medical-50 to-white">
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14">
          <h1 className="max-w-2xl text-3xl font-bold leading-tight tracking-tight text-slate-900 sm:text-4xl">
            Everyday healthcare essentials,
            <span className="text-medical-700"> dispensed in seconds</span>
          </h1>
          <p className="mt-3 max-w-xl text-sm leading-relaxed text-slate-600 sm:text-base">
            Browse over-the-counter products, pay by scanning a UPI QR code, and collect from the
            slot shown on screen.
          </p>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
            <div className="relative flex-1 sm:max-w-md">
              <svg
                viewBox="0 0 24 24"
                className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400"
                fill="currentColor"
                aria-hidden="true"
              >
                <path d="M10 2a8 8 0 1 0 4.9 14.32l5.39 5.39 1.42-1.42-5.39-5.39A8 8 0 0 0 10 2Zm0 2a6 6 0 1 1 0 12 6 6 0 0 1 0-12Z" />
              </svg>
              <input
                type="search"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Search by product, ingredient or use…"
                className="field pl-9"
                aria-label="Search products"
              />
            </div>
            <select
              value={sort}
              onChange={(event) => setSort(event.target.value)}
              className="field sm:w-48"
              aria-label="Sort products"
            >
              <option value="name_asc">Name (A–Z)</option>
              <option value="name_desc">Name (Z–A)</option>
              <option value="price_asc">Price (low to high)</option>
              <option value="price_desc">Price (high to low)</option>
            </select>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-6 sm:px-6">
        <CategoryTabs categories={categories} active={category} onSelect={setCategory} />

        <div className="mt-5 flex items-baseline justify-between">
          <h2 className="text-lg font-semibold text-slate-900">
            {activeCategory ? activeCategory.label : 'All products'}
          </h2>
          <p className="text-sm text-slate-500">
            {loading ? 'Loading…' : `${products.length} available`}
          </p>
        </div>
        {activeCategory && (
          <p className="mt-1 text-sm text-slate-500">{activeCategory.blurb}</p>
        )}

        {error && (
          <div className="mt-6 rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-800">
            Could not load products: {error}
          </div>
        )}

        {loading ? (
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {Array.from({ length: 8 }).map((_, index) => (
              <div key={index} className="card h-80 animate-pulse bg-slate-100" />
            ))}
          </div>
        ) : products.length === 0 ? (
          <div className="mt-10 rounded-xl border border-dashed border-slate-300 py-16 text-center">
            <p className="text-sm font-medium text-slate-700">No products match your search.</p>
            <p className="mt-1 text-sm text-slate-500">
              Try a different term, or clear the filters.
            </p>
            <button
              type="button"
              className="btn-ghost mt-4"
              onClick={() => {
                setSearch('');
                setCategory('');
              }}
            >
              Clear filters
            </button>
          </div>
        ) : (
          <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}

        <p className="mt-10 rounded-lg border border-slate-200 bg-white p-4 text-xs leading-relaxed text-slate-600">
          <strong className="font-semibold text-slate-800">Please note.</strong> This machine sells
          only products that do not require a prescription. Product information shown is sample data
          for a prototype and is not a substitute for the printed label. Always read the label, and
          consult a qualified healthcare professional if you are unsure whether a product is
          suitable for you.
        </p>
      </section>
    </>
  );
}

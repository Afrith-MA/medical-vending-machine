import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { api } from '../api.js';
import { useCart } from '../cart.js';
import { CATEGORY_LABELS, formatDate, formatINR } from '../lib/format.js';
import ProductImage from '../lib/ProductImage.jsx';

function Section({ title, children }) {
  return (
    <section className="border-t border-slate-200 py-5">
      <h2 className="text-sm font-semibold uppercase tracking-wide text-slate-500">{title}</h2>
      <div className="mt-2.5 text-sm leading-relaxed text-slate-700">{children}</div>
    </section>
  );
}

function Bullets({ items }) {
  if (!items?.length) return <p className="text-slate-400">Not applicable.</p>;
  return (
    <ul className="space-y-1.5">
      {items.map((item) => (
        <li key={item} className="flex gap-2">
          <span className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-medical-400" />
          <span>{item}</span>
        </li>
      ))}
    </ul>
  );
}

export default function Product() {
  const { id } = useParams();
  const navigate = useNavigate();
  const add = useCart((state) => state.add);

  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [error, setError] = useState(null);
  const [added, setAdded] = useState(false);

  useEffect(() => {
    setProduct(null);
    api
      .product(id)
      .then((row) => {
        setProduct(row);
        setQuantity(row.max_purchasable > 0 ? 1 : 0);
      })
      .catch((err) => setError(err.message));
  }, [id]);

  if (error) {
    return (
      <div className="mx-auto max-w-md px-4 py-24 text-center">
        <h1 className="text-lg font-semibold text-slate-900">{error}</h1>
        <Link to="/" className="btn-primary mt-6">
          Back to products
        </Link>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-10 sm:px-6">
        <div className="h-96 animate-pulse rounded-xl bg-slate-100" />
      </div>
    );
  }

  const unavailable = product.max_purchasable <= 0;

  return (
    <div className="mx-auto max-w-5xl px-4 py-6 sm:px-6 sm:py-10">
      <nav className="mb-5 text-sm text-slate-500">
        <Link to="/" className="hover:text-medical-700">
          Products
        </Link>
        <span className="mx-2">/</span>
        <span className="text-slate-700">{CATEGORY_LABELS[product.category]}</span>
      </nav>

      <div className="grid gap-8 md:grid-cols-[320px_1fr]">
        {/* -------------------------------------------------- buy panel */}
        <div className="md:sticky md:top-24 md:self-start">
          <div className="card overflow-hidden">
            <div className="bg-slate-50 p-6">
              <ProductImage product={product} className="mx-auto h-48 w-48" />
            </div>

            <div className="border-t border-slate-200 p-5">
              <p className="text-2xl font-bold tabular-nums text-slate-900">
                {formatINR(product.price_paise)}
              </p>
              {product.mrp_paise > product.price_paise && (
                <p className="mt-0.5 text-sm text-slate-400">
                  MRP <span className="line-through">{formatINR(product.mrp_paise)}</span> (incl.
                  all taxes)
                </p>
              )}

              <dl className="mt-4 space-y-2 text-sm">
                <div className="flex justify-between">
                  <dt className="text-slate-500">Machine slot</dt>
                  <dd className="font-mono font-semibold text-slate-900">{product.slot_code}</dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-slate-500">Availability</dt>
                  <dd
                    className={`font-semibold ${
                      unavailable ? 'text-rose-700' : 'text-vital-700'
                    }`}
                  >
                    {unavailable ? 'Unavailable' : `${product.stock} in machine`}
                  </dd>
                </div>
                <div className="flex justify-between">
                  <dt className="text-slate-500">Max per purchase</dt>
                  <dd className="font-semibold text-slate-900">
                    {product.max_qty_per_order ?? 3}
                  </dd>
                </div>
              </dl>

              {unavailable ? (
                <p className="mt-4 rounded-lg bg-rose-50 p-3 text-sm text-rose-800">
                  This product cannot be bought right now
                  {product.unavailable_reason ? ` (${product.unavailable_reason.replace('_', ' ')})` : ''}.
                </p>
              ) : (
                <>
                  <div className="mt-4 flex items-center gap-3">
                    <label htmlFor="qty" className="text-sm text-slate-600">
                      Quantity
                    </label>
                    <div className="inline-flex items-center rounded-lg border border-slate-300">
                      <button
                        type="button"
                        className="h-9 w-9 text-slate-600 hover:bg-slate-50 disabled:opacity-40"
                        disabled={quantity <= 1}
                        onClick={() => setQuantity((value) => Math.max(1, value - 1))}
                        aria-label="Reduce quantity"
                      >
                        −
                      </button>
                      <span id="qty" className="w-9 text-center text-sm font-semibold tabular-nums">
                        {quantity}
                      </span>
                      <button
                        type="button"
                        className="h-9 w-9 text-slate-600 hover:bg-slate-50 disabled:opacity-40"
                        disabled={quantity >= product.max_purchasable}
                        onClick={() =>
                          setQuantity((value) => Math.min(product.max_purchasable, value + 1))
                        }
                        aria-label="Increase quantity"
                      >
                        +
                      </button>
                    </div>
                  </div>
                  {quantity >= product.max_purchasable && (
                    <p className="mt-2 text-xs text-amber-700">
                      Maximum {product.max_purchasable} per purchase.
                    </p>
                  )}

                  <div className="mt-4 grid gap-2">
                    <button
                      type="button"
                      className={added ? 'btn-success' : 'btn-primary'}
                      onClick={() => {
                        add(product, quantity);
                        setAdded(true);
                        setTimeout(() => setAdded(false), 1400);
                      }}
                    >
                      {added ? 'Added to cart ✓' : 'Add to cart'}
                    </button>
                    <button
                      type="button"
                      className="btn-ghost"
                      onClick={() => {
                        add(product, quantity);
                        navigate('/checkout');
                      }}
                    >
                      Buy now
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>

        {/* ----------------------------------------------- label details */}
        <div>
          <span className="pill bg-medical-50 text-medical-700">
            {CATEGORY_LABELS[product.category]}
          </span>
          <h1 className="mt-2 text-2xl font-bold leading-tight text-slate-900 sm:text-3xl">
            {product.name}
          </h1>
          <p className="mt-1 text-sm text-slate-600">{product.generic_name}</p>
          <p className="mt-0.5 text-sm text-slate-500">{product.pack_size}</p>

          <div className="mt-4 rounded-lg border border-medical-200 bg-medical-50 p-4">
            <p className="text-sm leading-relaxed text-medical-900">
              <strong className="font-semibold">Before you buy.</strong> {product.label_notice}
            </p>
            <p className="mt-2 text-sm font-medium text-medical-800">
              This product does not require a prescription.
            </p>
          </div>

          {product.warnings?.length > 0 && (
            <div className="mt-4 rounded-lg border border-rose-200 bg-rose-50 p-4">
              <h2 className="flex items-center gap-2 text-sm font-semibold text-rose-900">
                <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor" aria-hidden="true">
                  <path d="M12 2 1 21h22L12 2Zm0 6 7.5 13h-15L12 8Zm-1 4v4h2v-4h-2Zm0 5v2h2v-2h-2Z" />
                </svg>
                Warnings — read before use
              </h2>
              <ul className="mt-2.5 space-y-1.5 text-sm leading-relaxed text-rose-900">
                {product.warnings.map((warning) => (
                  <li key={warning} className="flex gap-2">
                    <span className="mt-[7px] h-1.5 w-1.5 shrink-0 rounded-full bg-rose-500" />
                    <span>{warning}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          <Section title="Intended use">
            <Bullets items={product.uses} />
          </Section>

          <Section title="Directions for use">
            <p>{product.dosage_instructions}</p>
          </Section>

          <Section title="Composition">
            <Bullets items={product.composition} />
            {product.excipients?.length > 0 && (
              <p className="mt-3 text-xs text-slate-500">
                <span className="font-medium text-slate-600">Excipients:</span>{' '}
                {product.excipients.join(', ')}
              </p>
            )}
          </Section>

          {product.contraindications?.length > 0 && (
            <Section title="Do not use if">
              <Bullets items={product.contraindications} />
            </Section>
          )}

          {product.side_effects?.length > 0 && (
            <Section title="Possible side effects">
              <Bullets items={product.side_effects} />
            </Section>
          )}

          <Section title="Storage">
            <p>{product.storage_instructions}</p>
          </Section>

          <Section title="Product details">
            <dl className="grid gap-x-6 gap-y-3 sm:grid-cols-2">
              {[
                ['Manufacturer', product.manufacturer],
                ['Marketed by', product.marketer],
                ['Pack size', product.pack_size],
                ['Batch number', product.batch_number],
                ['Expiry date', formatDate(product.expiry_date)],
                ['GST rate', `${product.gst_rate}% (included in price)`],
                ['Machine slot', product.slot_code],
                ['Prescription required', 'No'],
              ].map(([label, value]) => (
                <div key={label}>
                  <dt className="text-xs uppercase tracking-wide text-slate-400">{label}</dt>
                  <dd className="mt-0.5 text-slate-800">{value || '—'}</dd>
                </div>
              ))}
            </dl>
          </Section>

          {product.is_sample_data && (
            <p className="mt-5 rounded-lg bg-slate-100 p-3 text-xs leading-relaxed text-slate-600">
              The details above are illustrative sample data for a software prototype. They are not
              transcribed from a specific approved product label, and the price is a placeholder.
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

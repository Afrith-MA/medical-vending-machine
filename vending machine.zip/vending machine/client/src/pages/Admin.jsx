import { useCallback, useEffect, useState } from 'react';
import { api } from '../api.js';
import {
  CATEGORY_LABELS,
  HIDDEN_REASON_LABELS,
  formatDate,
  formatDateTime,
  formatINR,
} from '../lib/format.js';

function Tile({ label, value, tone = 'slate', hint }) {
  const tones = {
    slate: 'text-slate-900',
    green: 'text-vital-700',
    amber: 'text-amber-700',
    rose: 'text-rose-700',
  };
  return (
    <div className="card p-4">
      <p className="text-xs uppercase tracking-wide text-slate-500">{label}</p>
      <p className={`mt-1 text-2xl font-bold tabular-nums ${tones[tone]}`}>{value}</p>
      {hint && <p className="mt-0.5 text-xs text-slate-500">{hint}</p>}
    </div>
  );
}

function StatusPill({ status }) {
  const tone =
    {
      dispensed: 'bg-vital-100 text-vital-800',
      paid: 'bg-medical-100 text-medical-800',
      awaiting_payment: 'bg-slate-100 text-slate-700',
      payment_failed: 'bg-rose-100 text-rose-800',
      dispense_failed: 'bg-rose-100 text-rose-800',
      partially_dispensed: 'bg-amber-100 text-amber-800',
      cancelled: 'bg-slate-100 text-slate-500',
    }[status] || 'bg-slate-100 text-slate-700';
  return <span className={`pill ${tone}`}>{status.replace(/_/g, ' ')}</span>;
}

/* ------------------------------------------------------------- inventory */

function InventoryRow({ product, onChange }) {
  const [price, setPrice] = useState((product.price_paise / 100).toFixed(2));
  const [restock, setRestock] = useState('');
  const [saving, setSaving] = useState(false);

  async function run(action) {
    setSaving(true);
    try {
      await action();
      await onChange();
    } finally {
      setSaving(false);
    }
  }

  const expiringSoon = product.days_to_expiry >= 0 && product.days_to_expiry <= 30;

  return (
    <tr className="border-b border-slate-100 align-top">
      <td className="py-3 pr-3">
        <p className="text-sm font-medium text-slate-900">{product.name}</p>
        <p className="text-xs text-slate-500">
          {CATEGORY_LABELS[product.category]} · {product.pack_size}
        </p>
        <p className="mt-0.5 font-mono text-[11px] text-slate-400">
          {product.sku} · batch {product.batch_number}
        </p>
      </td>

      <td className="py-3 pr-3 text-center">
        <span className="font-mono text-sm font-semibold">{product.slot_code}</span>
      </td>

      <td className="py-3 pr-3">
        <div className="flex items-center gap-1">
          <span className="text-xs text-slate-400">₹</span>
          <input
            value={price}
            onChange={(event) => setPrice(event.target.value)}
            onBlur={() => {
              const paise = Math.round(Number(price) * 100);
              if (Number.isFinite(paise) && paise > 0 && paise !== product.price_paise) {
                run(() => api.admin.updateProduct(product.id, { price_paise: paise }));
              }
            }}
            className="w-20 rounded border border-slate-300 px-2 py-1 text-sm tabular-nums"
            aria-label={`Price for ${product.name}`}
          />
        </div>
      </td>

      <td className="py-3 pr-3">
        <div className="flex items-center gap-2">
          <span
            className={`pill ${
              product.stock === 0
                ? 'bg-rose-100 text-rose-800'
                : product.stock <= 3
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-vital-100 text-vital-800'
            }`}
          >
            {product.stock}/{product.capacity}
          </span>
          <input
            value={restock}
            onChange={(event) => setRestock(event.target.value.replace(/\D/g, ''))}
            placeholder="+"
            className="w-12 rounded border border-slate-300 px-2 py-1 text-sm"
            aria-label={`Restock quantity for ${product.name}`}
          />
          <button
            type="button"
            disabled={!restock || saving}
            className="rounded border border-slate-300 px-2 py-1 text-xs hover:bg-slate-50 disabled:opacity-40"
            onClick={() =>
              run(async () => {
                await api.admin.restock(product.id, Number(restock));
                setRestock('');
              })
            }
          >
            Add
          </button>
        </div>
      </td>

      <td className="py-3 pr-3">
        <p className={`text-sm tabular-nums ${expiringSoon ? 'text-amber-700' : 'text-slate-700'}`}>
          {formatDate(product.expiry_date)}
        </p>
        <p className="text-[11px] text-slate-500">
          {product.days_to_expiry < 0
            ? `expired ${Math.abs(product.days_to_expiry)}d ago`
            : `${product.days_to_expiry}d left`}
        </p>
      </td>

      <td className="py-3 pr-3">
        {product.hidden_reason ? (
          <span className="pill bg-rose-100 text-rose-800">
            {HIDDEN_REASON_LABELS[product.hidden_reason] || product.hidden_reason}
          </span>
        ) : (
          <span className="pill bg-vital-100 text-vital-800">On sale</span>
        )}
        {product.recall_reason && (
          <p className="mt-1 max-w-[220px] text-[11px] leading-snug text-rose-700">
            {product.recall_reason}
          </p>
        )}
      </td>

      <td className="py-3 text-right">
        <button
          type="button"
          disabled={saving}
          className={`rounded border px-2.5 py-1 text-xs font-medium ${
            product.is_recalled
              ? 'border-vital-300 text-vital-700 hover:bg-vital-50'
              : 'border-rose-300 text-rose-700 hover:bg-rose-50'
          }`}
          onClick={() =>
            run(() =>
              api.admin.updateProduct(product.id, {
                is_recalled: !product.is_recalled,
                recall_reason: product.is_recalled ? null : 'Recalled by operator.',
              }),
            )
          }
        >
          {product.is_recalled ? 'Lift recall' : 'Recall'}
        </button>
      </td>
    </tr>
  );
}

/* ------------------------------------------------------------------ page */

export default function Admin() {
  const [tab, setTab] = useState('overview');
  const [products, setProducts] = useState([]);
  const [orders, setOrders] = useState([]);
  const [report, setReport] = useState(null);
  const [loading, setLoading] = useState(true);

  const refresh = useCallback(async () => {
    const [productRows, orderRows, reportData] = await Promise.all([
      api.admin.products(),
      api.admin.orders(),
      api.admin.report(),
    ]);
    setProducts(productRows);
    setOrders(orderRows);
    setReport(reportData);
    setLoading(false);
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const tabs = [
    ['overview', 'Overview'],
    ['inventory', `Inventory (${products.length})`],
    ['orders', `Orders (${orders.length})`],
  ];

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <div className="rounded-lg border border-rose-300 bg-rose-50 px-4 py-3">
        <p className="text-sm font-semibold text-rose-900">
          Admin dashboard — no authentication
        </p>
        <p className="mt-0.5 text-xs leading-relaxed text-rose-800">
          Anyone who can reach this page can change prices, stock and recalls. This is acceptable
          only for a local demo. Do not expose this server beyond localhost.
        </p>
      </div>

      <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold text-slate-900">Machine administration</h1>
        <div className="flex gap-2">
          <button type="button" className="btn-ghost text-xs" onClick={refresh}>
            Refresh
          </button>
          <button
            type="button"
            className="btn-ghost text-xs"
            onClick={async () => {
              await api.admin.reset();
              await refresh();
            }}
            title="Restore the seeded catalogue and clear all orders"
          >
            Reset demo data
          </button>
        </div>
      </div>

      <div className="mt-5 flex gap-1 border-b border-slate-200">
        {tabs.map(([key, label]) => (
          <button
            key={key}
            type="button"
            onClick={() => setTab(key)}
            className={`-mb-px border-b-2 px-4 py-2.5 text-sm font-medium ${
              tab === key
                ? 'border-medical-600 text-medical-700'
                : 'border-transparent text-slate-500 hover:text-slate-800'
            }`}
          >
            {label}
          </button>
        ))}
      </div>

      {loading && <p className="mt-8 text-sm text-slate-500">Loading…</p>}

      {/* ---------------------------------------------------- overview */}
      {!loading && tab === 'overview' && report && (
        <div className="mt-6 space-y-6">
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            <Tile
              label="Revenue"
              value={formatINR(report.revenue_paise)}
              tone="green"
              hint="net of refunds"
            />
            <Tile
              label="Orders paid"
              value={`${report.orders_paid}/${report.orders_total}`}
            />
            <Tile
              label="Refunds"
              value={formatINR(report.refunds_paise)}
              tone={report.refunds_paise > 0 ? 'rose' : 'slate'}
            />
            <Tile
              label="Dispense failures"
              value={`${report.dispense_failure_rate}%`}
              tone={report.dispense_failure_rate > 20 ? 'rose' : 'slate'}
              hint={`${report.dispense_failures} of ${report.dispense_attempts} attempts`}
            />
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
            <Tile label="Out of stock" value={report.alerts.out_of_stock} tone="rose" />
            <Tile label="Low stock" value={report.alerts.low_stock} tone="amber" />
            <Tile label="Expired" value={report.alerts.expired} tone="rose" />
            <Tile label="Expiring ≤30d" value={report.alerts.expiring_soon} tone="amber" />
            <Tile label="Recalled" value={report.alerts.recalled} tone="rose" />
          </div>

          <div className="card p-5">
            <h2 className="text-sm font-semibold text-slate-900">Top products by units sold</h2>
            {report.top_products.length === 0 ? (
              <p className="mt-2 text-sm text-slate-500">
                No items dispensed yet. Complete a purchase to populate this report.
              </p>
            ) : (
              <ul className="mt-3 space-y-2">
                {report.top_products.map((row) => (
                  <li key={row.name} className="flex items-center gap-3 text-sm">
                    <span className="flex-1 truncate text-slate-700">{row.name}</span>
                    <span className="h-2 w-32 overflow-hidden rounded-full bg-slate-100">
                      <span
                        className="block h-full rounded-full bg-medical-500"
                        style={{
                          width: `${(row.units / report.top_products[0].units) * 100}%`,
                        }}
                      />
                    </span>
                    <span className="w-8 text-right font-semibold tabular-nums">{row.units}</span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </div>
      )}

      {/* --------------------------------------------------- inventory */}
      {!loading && tab === 'inventory' && (
        <div className="mt-6 overflow-x-auto">
          <p className="mb-3 text-sm text-slate-600">
            Expired and recalled products are removed from the storefront automatically — they stay
            listed here with the reason.
          </p>
          <table className="w-full min-w-[920px]">
            <thead>
              <tr className="border-b border-slate-200 text-left text-xs uppercase tracking-wide text-slate-500">
                <th className="pb-2 font-medium">Product</th>
                <th className="pb-2 text-center font-medium">Slot</th>
                <th className="pb-2 font-medium">Price</th>
                <th className="pb-2 font-medium">Stock</th>
                <th className="pb-2 font-medium">Expiry</th>
                <th className="pb-2 font-medium">Store status</th>
                <th className="pb-2 text-right font-medium">Action</th>
              </tr>
            </thead>
            <tbody>
              {products.map((product) => (
                <InventoryRow key={product.id} product={product} onChange={refresh} />
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* ------------------------------------------------------ orders */}
      {!loading && tab === 'orders' && (
        <div className="mt-6">
          {orders.length === 0 ? (
            <div className="card p-12 text-center">
              <p className="text-sm text-slate-600">No orders yet.</p>
              <p className="mt-1 text-xs text-slate-500">
                Buy something from the storefront to see it appear here.
              </p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full min-w-[760px]">
                <thead>
                  <tr className="border-b border-slate-200 text-left text-xs uppercase tracking-wide text-slate-500">
                    <th className="pb-2 font-medium">Order</th>
                    <th className="pb-2 font-medium">Placed</th>
                    <th className="pb-2 font-medium">Items</th>
                    <th className="pb-2 font-medium">Status</th>
                    <th className="pb-2 text-right font-medium">Total</th>
                    <th className="pb-2 text-right font-medium">Refund</th>
                  </tr>
                </thead>
                <tbody>
                  {orders.map((order) => (
                    <tr key={order.id} className="border-b border-slate-100">
                      <td className="py-3 font-mono text-xs text-slate-800">
                        {order.id}
                        <span className="mt-0.5 block text-slate-400">
                          {order.collection_code}
                        </span>
                      </td>
                      <td className="py-3 text-sm text-slate-600">
                        {formatDateTime(order.created_at)}
                      </td>
                      <td className="py-3 text-sm text-slate-700">
                        {order.items.map((item) => (
                          <span key={item.product_id} className="block truncate">
                            {item.quantity} × {item.product_name}
                          </span>
                        ))}
                      </td>
                      <td className="py-3">
                        <StatusPill status={order.status} />
                      </td>
                      <td className="py-3 text-right text-sm font-semibold tabular-nums">
                        {formatINR(order.total_paise)}
                      </td>
                      <td className="py-3 text-right text-sm tabular-nums text-rose-700">
                        {order.refund_amount_paise
                          ? `−${formatINR(order.refund_amount_paise)}`
                          : '—'}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

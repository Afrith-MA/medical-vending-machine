import { create } from 'zustand';
import { persist } from 'zustand/middleware';

/**
 * The cart is a convenience only. Quantities are capped here for a sensible
 * UI, but the server re-prices and re-caps everything at checkout — the client
 * is never the authority on price or stock.
 */
export const useCart = create(
  persist(
    (set, get) => ({
      items: [], // { product_id, name, pack_size, price_paise, category, image_seed, quantity, max }

      add(product, quantity = 1) {
        const cap = product.max_purchasable ?? 1;
        if (cap <= 0) return;

        const items = [...get().items];
        const existing = items.find((item) => item.product_id === product.id);

        if (existing) {
          existing.quantity = Math.min(existing.quantity + quantity, cap);
          existing.max = cap;
        } else {
          items.push({
            product_id: product.id,
            name: product.name,
            pack_size: product.pack_size,
            price_paise: product.price_paise,
            category: product.category,
            image_seed: product.image_seed,
            quantity: Math.min(quantity, cap),
            max: cap,
          });
        }
        set({ items });
      },

      setQuantity(productId, quantity) {
        const items = get()
          .items.map((item) =>
            item.product_id === productId
              ? { ...item, quantity: Math.max(0, Math.min(quantity, item.max)) }
              : item,
          )
          .filter((item) => item.quantity > 0);
        set({ items });
      },

      remove(productId) {
        set({ items: get().items.filter((item) => item.product_id !== productId) });
      },

      clear() {
        set({ items: [] });
      },

      count() {
        return get().items.reduce((total, item) => total + item.quantity, 0);
      },

      total() {
        return get().items.reduce((total, item) => total + item.price_paise * item.quantity, 0);
      },

      /** Payload shape the server's cart/order endpoints expect. */
      lines() {
        return get().items.map((item) => ({
          product_id: item.product_id,
          quantity: item.quantity,
        }));
      },
    }),
    { name: 'smvm-cart' },
  ),
);

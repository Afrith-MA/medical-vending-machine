import { useEffect, useState } from 'react';
import { Link, NavLink, Route, Routes, useLocation } from 'react-router-dom';
import { api } from './api.js';
import { useCart } from './cart.js';
import CartDrawer from './components/CartDrawer.jsx';
import Home from './pages/Home.jsx';
import Product from './pages/Product.jsx';
import Checkout from './pages/Checkout.jsx';
import Order from './pages/Order.jsx';
import Admin from './pages/Admin.jsx';

function Logo() {
  return (
    <Link to="/" className="flex items-center gap-2.5">
      <span className="grid h-9 w-9 place-items-center rounded-lg bg-medical-600 text-white">
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="currentColor" aria-hidden="true">
          <path d="M10 3h4v5h5v4h-5v5h-4v-5H5V8h5V3Z" />
        </svg>
      </span>
      <span className="leading-tight">
        <span className="block text-[15px] font-bold text-slate-900">
          Smart Medical Vending Machine
        </span>
        <span className="block text-[11px] font-medium text-slate-500">
          Over-the-counter healthcare, on demand
        </span>
      </span>
    </Link>
  );
}

function Header({ onOpenCart }) {
  const count = useCart((state) => state.items.reduce((sum, item) => sum + item.quantity, 0));

  return (
    <header className="sticky top-0 z-30 border-b border-slate-200 bg-white/90 backdrop-blur no-print">
      <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 sm:px-6">
        <Logo />
        <nav className="ml-auto flex items-center gap-1">
          <NavLink
            to="/"
            end
            className={({ isActive }) =>
              `hidden rounded-lg px-3 py-2 text-sm font-medium sm:block ${
                isActive ? 'bg-medical-50 text-medical-700' : 'text-slate-600 hover:bg-slate-100'
              }`
            }
          >
            Shop
          </NavLink>
          <NavLink
            to="/admin"
            className={({ isActive }) =>
              `hidden rounded-lg px-3 py-2 text-sm font-medium sm:block ${
                isActive ? 'bg-medical-50 text-medical-700' : 'text-slate-600 hover:bg-slate-100'
              }`
            }
          >
            Admin
          </NavLink>
          <button type="button" onClick={onOpenCart} className="btn-primary relative ml-1">
            <svg viewBox="0 0 24 24" className="h-4 w-4" fill="currentColor" aria-hidden="true">
              <path d="M7 4h-2l-1 2H2v2h2l3 8h10l3-8H7.4L7 4Zm1 16a2 2 0 1 0 0-4 2 2 0 0 0 0 4Zm9 0a2 2 0 1 0 0-4 2 2 0 0 0 0 4Z" />
            </svg>
            <span className="hidden sm:inline">Cart</span>
            {count > 0 && (
              <span className="grid h-5 min-w-[20px] place-items-center rounded-full bg-white px-1 text-[11px] font-bold text-medical-700">
                {count}
              </span>
            )}
          </button>
        </nav>
      </div>
    </header>
  );
}

function DemoBanner({ health }) {
  if (!health) return null;
  return (
    <div className="border-b border-amber-200 bg-amber-50 no-print">
      <p className="mx-auto max-w-7xl px-4 py-2 text-[12px] leading-snug text-amber-900 sm:px-6">
        <strong className="font-semibold">Demonstration prototype.</strong> Payment and dispensing
        are simulated — no money is taken and no hardware is attached. Product details are sample
        data, not a real product label. Data resets when the server restarts.
      </p>
    </div>
  );
}

function Footer({ health }) {
  return (
    <footer className="mt-16 border-t border-slate-200 bg-white no-print">
      <div className="mx-auto grid max-w-7xl gap-8 px-4 py-10 sm:px-6 md:grid-cols-3">
        <div>
          <h3 className="text-sm font-semibold text-slate-900">About this machine</h3>
          <p className="mt-2 text-sm leading-relaxed text-slate-600">
            This machine stocks only products that may be sold without a prescription. It does not
            offer prescription medicines, and it does not recommend products for symptoms.
          </p>
        </div>
        <div>
          <h3 className="text-sm font-semibold text-slate-900">Before you buy</h3>
          <p className="mt-2 text-sm leading-relaxed text-slate-600">
            Always read the label and the enclosed leaflet. If you are unsure whether a product is
            suitable for you, consult a qualified healthcare professional.
          </p>
        </div>
        <div>
          <h3 className="text-sm font-semibold text-slate-900">Support</h3>
          <dl className="mt-2 space-y-1 text-sm text-slate-600">
            <div className="flex gap-2">
              <dt className="text-slate-500">Helpline</dt>
              <dd className="font-medium text-slate-800">
                {health?.support_phone || '1800-000-0000'}
              </dd>
            </div>
            <div className="flex gap-2">
              <dt className="text-slate-500">Machine</dt>
              <dd className="font-mono text-slate-800">{health?.machine_id || 'VM-DEMO-01'}</dd>
            </div>
          </dl>
          <p className="mt-3 text-xs text-slate-500">
            If an item does not drop, do not shake the machine — note your order ID and call the
            helpline.
          </p>
        </div>
      </div>
      <div className="border-t border-slate-100 py-4 text-center text-xs text-slate-400">
        Smart Medical Vending Machine — software prototype
      </div>
    </footer>
  );
}

export default function App() {
  const [cartOpen, setCartOpen] = useState(false);
  const [health, setHealth] = useState(null);
  const location = useLocation();

  useEffect(() => {
    api.health().then(setHealth).catch(() => setHealth(null));
  }, []);

  // Close the cart whenever the route changes.
  useEffect(() => setCartOpen(false), [location.pathname]);

  return (
    <div className="flex min-h-screen flex-col">
      <Header onOpenCart={() => setCartOpen(true)} />
      <DemoBanner health={health} />

      <main className="flex-1">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/product/:id" element={<Product />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/order/:id" element={<Order />} />
          <Route path="/admin" element={<Admin />} />
          <Route
            path="*"
            element={
              <div className="mx-auto max-w-md px-4 py-24 text-center">
                <h1 className="text-xl font-semibold text-slate-900">Page not found</h1>
                <Link to="/" className="btn-primary mt-6">
                  Back to products
                </Link>
              </div>
            }
          />
        </Routes>
      </main>

      <Footer health={health} />
      <CartDrawer open={cartOpen} onClose={() => setCartOpen(false)} />
    </div>
  );
}

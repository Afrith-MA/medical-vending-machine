import { useNavigate } from 'react-router-dom';
import { useCart } from '../cart.js';
import { formatINR } from '../lib/format.js';
import ProductImage from '../lib/ProductImage.jsx';

function QuantityStepper({ item, onChange }) {
  const atMax = item.quantity >= item.max;
  return (
    <div className="inline-flex items-center rounded-lg border border-slate-300">
      <button
        type="button"
        className="grid h-8 w-8 place-items-center text-slate-600 hover:bg-slate-50 disabled:opacity-40"
        onClick={() => onChange(item.quantity - 1)}
        aria-label={`Reduce quantity of ${item.name}`}
      >
        −
      </button>
      <span className="w-8 text-center text-sm font-semibold tabular-nums">{item.quantity}</span>
      <button
        type="button"
        disabled={atMax}
        className="grid h-8 w-8 place-items-center text-slate-600 hover:bg-slate-50 disabled:opacity-40"
        onClick={() => onChange(item.quantity + 1)}
        aria-label={`Increase quantity of ${item.name}`}
        title={atMax ? `Maximum ${item.max} per purchase` : undefined}
      >
        +
      </button>
    </div>
  );
}

export default function CartDrawer({ open, onClose }) {
  const navigate = useNavigate();
  const { items, setQuantity, remove } = useCart();
  const total = items.reduce((sum, item) => sum + item.price_paise * item.quantity, 0);

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50 no-print" role="dialog" aria-modal="true" aria-label="Shopping cart">
      <button
        type="button"
        className="absolute inset-0 bg-slate-900/40"
        onClick={onClose}
        aria-label="Close cart"
      />

      <aside className="absolute right-0 top-0 flex h-full w-full max-w-md animate-slide-in-right flex-col bg-white shadow-2xl">
        <header className="flex items-center justify-between border-b border-slate-200 px-5 py-4">
          <h2 className="text-base font-semibold text-slate-900">
            Your cart
            {items.length > 0 && (
              <span className="ml-2 text-sm font-normal text-slate-500">
                ({items.reduce((sum, item) => sum + item.quantity, 0)} items)
              </span>
            )}
          </h2>
          <button
            type="button"
            onClick={onClose}
            className="grid h-8 w-8 place-items-center rounded-lg text-slate-500 hover:bg-slate-100"
            aria-label="Close"
          >
            ✕
          </button>
        </header>

        {items.length === 0 ? (
          <div className="flex flex-1 flex-col items-center justify-center gap-3 px-6 text-center">
            <p className="text-sm text-slate-500">Your cart is empty.</p>
            <button type="button" className="btn-ghost" onClick={onClose}>
              Browse products
            </button>
          </div>
        ) : (
          <>
            <ul className="flex-1 divide-y divide-slate-100 overflow-y-auto px-5">
              {items.map((item) => (
                <li key={item.product_id} className="flex gap-3 py-4">
                  <ProductImage product={item} className="h-16 w-16 shrink-0 rounded-lg" />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-slate-900">{item.name}</p>
                    <p className="text-xs text-slate-500">{item.pack_size}</p>
                    <div className="mt-2 flex items-center gap-3">
                      <QuantityStepper
                        item={item}
                        onChange={(next) => setQuantity(item.product_id, next)}
                      />
                      <button
                        type="button"
                        className="text-xs font-medium text-rose-600 hover:underline"
                        onClick={() => remove(item.product_id)}
                      >
                        Remove
                      </button>
                    </div>
                    {item.quantity >= item.max && (
                      <p className="mt-1.5 text-[11px] text-amber-700">
                        Maximum {item.max} per purchase.
                      </p>
                    )}
                  </div>
                  <p className="shrink-0 text-sm font-semibold tabular-nums text-slate-900">
                    {formatINR(item.price_paise * item.quantity)}
                  </p>
                </li>
              ))}
            </ul>

            <footer className="border-t border-slate-200 px-5 py-4">
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-600">Total (incl. GST)</span>
                <span className="text-lg font-bold tabular-nums text-slate-900">
                  {formatINR(total)}
                </span>
              </div>
              <button
                type="button"
                className="btn-primary mt-3 w-full"
                onClick={() => navigate('/checkout')}
              >
                Checkout
              </button>
              <p className="mt-2 text-center text-[11px] text-slate-500">
                Read the label before use. Consult a healthcare professional if unsure.
              </p>
            </footer>
          </>
        )}
      </aside>
    </div>
  );
}

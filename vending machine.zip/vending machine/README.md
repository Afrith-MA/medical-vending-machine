# Smart Medical Vending Machine

A working software prototype of a medical vending machine. A customer browses
over-the-counter healthcare products, reads the label information, adds items to
a cart, pays by scanning a UPI QR code, and is given a slot number to collect
from. An admin page manages stock, prices, expiry and recalls, and shows orders
and sales.

> **This is a demonstration prototype.** Payment and dispensing are simulated,
> no money is taken, no hardware is attached, and all data is lost when the
> server restarts. Product details are illustrative sample data, not real
> product labels.

---

## Running it

```bash
npm install
```

```bash
npm run dev
```

- Storefront → http://localhost:5173
- Admin → http://localhost:5173/admin
- API → http://localhost:4100/api/health

No database, no API keys, no accounts. It runs as-is.

To run just one side: `npm run dev:server` or `npm run dev:client`.

---

## What it does

**Browse** — 32 seeded products across six categories (pain relief, cold &
cough, first aid, digestive health, personal hygiene, healthcare supplies), with
search by name, ingredient or use, sorting, and a responsive grid.

**Read the label** — each product page shows composition, intended use,
directions, warnings, contraindications, side effects, storage, manufacturer,
pack size, batch number and expiry date, plus a notice to read the label and
consult a healthcare professional.

**Buy** — add to cart with quantities capped at both the stock in the machine
and the per-purchase limit for that product. The server re-prices and re-checks
the whole cart at checkout and tells you about anything it changed.

**Pay** — a scannable UPI QR code for the exact amount, with the order ID in the
payment note.

**Collect** — on payment, the order gets an ID, a collection code and a slot
number, and the machine dispenses. If a slot fails, the machine retries once,
returns the stock, and initiates a refund for exactly the undispensed value.

**Administer** — inventory with live store status, inline price edits,
restocking, recall toggles, expiry tracking, an order list and a sales report
with dispense failure rates.

---

## How the safety rules work

These are the parts worth keeping if the prototype is ever extended.

**One rule decides what can be sold.** `blockedReason()` in
`server/src/server.js` returns why a product may not be sold — `recalled`,
`expired`, `out_of_stock`, `inactive` or `prescription_only` — or `null` if it
may. It is called in four places: listing the catalogue, validating the cart,
creating an order, and once more immediately before the dispense command, so a
recall that lands mid-checkout still stops the product being handed over.

**Expired and recalled stock disappears by itself.** Blocked products are
omitted from the storefront entirely and shown in the admin inventory with the
reason. Recalling a batch in the admin page removes it from the shop
immediately. The seed data deliberately includes one expired product, one
recalled product, one sold out and one expiring within 30 days, so this is
visible without editing anything.

**The client is never trusted on price or stock.** The cart in the browser is a
convenience; `priceCart()` recomputes every line from live server data, so a
tampered payload cannot change what is charged or bypass a stock cap.

**Dispensing is gated on payment.** `POST /api/orders/:id/dispense` returns
`403 PAYMENT_NOT_VERIFIED` unless the server itself has already moved the order
to `paid`. The endpoint is idempotent — calling it twice returns the first
result rather than dispensing twice.

**No medical advice anywhere.** The application displays label information. It
never suggests a product for a symptom, and it stocks nothing that requires a
prescription.

---

## What is simulated, and where real code would go

| Simulated | Where | What a real system would do |
|---|---|---|
| Payment confirmation | `POST /api/orders/:id/simulate-payment` | This endpoint would not exist. A payment provider would confirm the payment with a signed webhook, or the server would poll the provider's API. The browser would never be the source of truth. |
| The QR code | `upiIntentUrl()` | The QR is a genuine UPI deep link, so it scans. A real system would generate a dynamic QR through a payment gateway so the payment can be matched to the order automatically. |
| Dispensing | `simulateDispense()` | Send a command to the vending controller over serial or MQTT and wait for a drop-sensor acknowledgement. |
| Storage | the `db` object | A real database. Orders, stock, batches and slots would be tables; see "Not built" below. |
| Admin access | none | Authentication and an audit trail. |

---

## Project layout

```
server/
  src/server.js            Everything: data, safety rules, pricing, routes
  src/data/catalog.data.js The 32 sample products and their label text
client/
  src/App.jsx              Layout, header, footer, routes
  src/api.js               Typed wrapper around the REST API
  src/cart.js              Cart state (zustand, persisted to localStorage)
  src/pages/Home.jsx       Catalogue, search, categories
  src/pages/Product.jsx    Full label view
  src/pages/Checkout.jsx   Server-validated order review
  src/pages/Order.jsx      QR payment, dispensing, receipt
  src/pages/Admin.jsx      Inventory, orders, reports
  src/lib/ProductImage.jsx Generated SVG artwork — no image files, no network
```

Product images are generated, not fetched: a hand-drawn SVG silhouette per
category, tinted by a hash of the product's SKU. Two products in the same
category look different, nothing is downloaded, and there is no artwork to
maintain.

---

## Known limitations

- **Nothing persists.** Restarting the server resets stock, orders and any admin
  edits back to the seeded catalogue. There is a "Reset demo data" button in the
  admin page to do this on purpose.
- **The admin page has no authentication.** Anyone who can reach it can change
  prices, stock and recalls. Do not expose this server beyond localhost.
- **Payment is simulated.** No payment provider is connected and no money moves.
- **Dispensing is simulated.** No hardware is attached. `SIM_FAILURE_RATE`
  controls how often a dispense fails; set it to `1` to exercise the refund path.
- **Stock is reserved at order creation**, not with a timeout. An order left
  unpaid holds its stock until it is cancelled. A real system would expire
  abandoned reservations.
- **Product data is illustrative.** Names, composition and label text are
  written against the standard text for each active ingredient, but manufacturers
  and prices are placeholders. Before any real use, every record must be replaced
  with text transcribed from the approved label of the product actually stocked.

## Not built

Deliberately left out to keep the prototype readable: a real database (MySQL
schema, batches and slots as separate tables), a real payment gateway, hardware
integration, customer accounts, and automated tests.

/**
 * Smart Medical Vending Machine — demo backend.
 *
 * Everything lives in this one file on purpose: it is a prototype meant to be
 * read in one sitting. Data is held in memory and is LOST when the process
 * stops. Payment and dispensing are SIMULATED — see the clearly marked
 * sections below for exactly where real integrations would go.
 */
import express from 'express';
import cors from 'cors';
import crypto from 'node:crypto';
import QRCode from 'qrcode';

import { PRODUCTS, CATEGORIES, LABEL_NOTICE, DATA_DISCLAIMER } from './data/catalog.data.js';

const PORT = process.env.PORT || 4100;
const MACHINE_ID = 'VM-DEMO-01';
const UPI_VPA = process.env.UPI_VPA || 'demo@upi';
const UPI_PAYEE = 'Smart Medical Vending Machine (DEMO)';
const SUPPORT_PHONE = '1800-000-0000';

// Chance a single simulated dispense attempt fails. Set to 1 to always exercise
// the failure + refund path.
const SIM_FAILURE_RATE = Number(process.env.SIM_FAILURE_RATE ?? 0.08);

const DAY_MS = 24 * 60 * 60 * 1000;
const isoDay = (offsetDays) =>
  new Date(Date.now() + offsetDays * DAY_MS).toISOString().slice(0, 10);

// ---------------------------------------------------------------------------
// In-memory data
// ---------------------------------------------------------------------------

/**
 * Deliberate edge cases so the safety rules are visible in the demo without
 * editing data by hand: one expired batch, one recalled batch, one sold out.
 * All three are hidden from the storefront and visible in the admin page.
 */
const EDGE_CASES = {
  'PR-BALM-8': { expiryDays: -12 }, // already expired
  'CC-LOZ-10': { expiryDays: 21 }, // expiring soon — admin alert only
  'DG-ANTACID-CHEW': {
    expiryDays: 420,
    recalled: true,
    recallReason: 'Voluntary recall — packaging integrity issue reported by the manufacturer.',
  },
  'PH-WIPES-10': { expiryDays: 480, stock: 0 }, // sold out
};

const SLOT_ROWS = ['A', 'B', 'C', 'D', 'E', 'F'];

const db = {
  products: [],
  orders: [],
};

function seed() {
  db.products = PRODUCTS.map((definition, index) => {
    const edge = EDGE_CASES[definition.sku] || {};
    const row = SLOT_ROWS[Math.floor(index / 8)] || 'F';
    const column = (index % 8) + 1;
    return {
      ...definition,
      id: `PRD-${String(index + 1).padStart(3, '0')}`,
      // Slot + batch are collapsed onto the product to keep the demo simple.
      // A real machine would model slots and batches as their own tables.
      slot_code: `${row}${column}`,
      batch_number: `B${String(index + 1).padStart(4, '0')}`,
      expiry_date: isoDay(edge.expiryDays ?? 300 + (index % 9) * 45),
      stock: edge.stock ?? 12,
      capacity: 12,
      is_recalled: Boolean(edge.recalled),
      recall_reason: edge.recallReason || null,
      is_active: true,
      is_otc: true,
      image_seed: definition.sku,
    };
  });
  db.orders = [];
}
seed();

// ---------------------------------------------------------------------------
// Safety rules — the single place that decides whether a product can be sold
// ---------------------------------------------------------------------------

/** Expiry dates are inclusive of the stated day. */
function isExpired(product, now = Date.now()) {
  return now > new Date(`${product.expiry_date}T23:59:59.999Z`).getTime();
}

function daysToExpiry(product, now = Date.now()) {
  return Math.floor(
    (new Date(`${product.expiry_date}T23:59:59.999Z`).getTime() - now) / DAY_MS,
  );
}

/**
 * Why a product may not be sold right now, or null if it may.
 * Called when listing the catalogue, when validating a cart, when creating an
 * order, and once more immediately before dispensing.
 */
function blockedReason(product) {
  if (!product.is_active) return 'inactive';
  if (!product.is_otc) return 'prescription_only';
  if (product.is_recalled) return 'recalled';
  if (isExpired(product)) return 'expired';
  if (product.stock <= 0) return 'out_of_stock';
  return null;
}

const maxPurchasable = (product) =>
  Math.min(product.stock, product.max_qty_per_order ?? 3);

/** Shape sent to the storefront. */
function toPublic(product) {
  const reason = blockedReason(product);
  return {
    id: product.id,
    sku: product.sku,
    name: product.name,
    generic_name: product.generic_name,
    category: product.category,
    form: product.form,
    pack_size: product.pack_size,
    price_paise: product.price_paise,
    mrp_paise: product.mrp_paise,
    gst_rate: product.gst_rate,
    manufacturer: product.manufacturer,
    marketer: product.marketer,
    composition: product.composition,
    excipients: product.excipients,
    uses: product.uses,
    dosage_instructions: product.dosage_instructions,
    warnings: product.warnings,
    side_effects: product.side_effects,
    contraindications: product.contraindications,
    storage_instructions: product.storage_instructions,
    expiry_date: product.expiry_date,
    batch_number: product.batch_number,
    slot_code: product.slot_code,
    prescription_required: false,
    is_sample_data: true,
    image_seed: product.image_seed,
    stock: product.stock,
    max_qty_per_order: product.max_qty_per_order ?? 3,
    max_purchasable: reason ? 0 : maxPurchasable(product),
    unavailable_reason: reason,
    label_notice: LABEL_NOTICE,
  };
}

// ---------------------------------------------------------------------------
// Pricing — all money is integer paise; Indian MRP is GST-inclusive
// ---------------------------------------------------------------------------

const gstComponent = (inclusive, rate) =>
  rate > 0 ? Math.round(inclusive - inclusive / (1 + rate / 100)) : 0;

/**
 * Recomputes a cart from live server data. The client's prices and quantities
 * are never trusted — this is what determines what is charged.
 */
function priceCart(lines) {
  const items = [];
  const notices = [];

  const requested = new Map();
  for (const line of lines || []) {
    const quantity = Number(line.quantity) || 0;
    if (quantity > 0) {
      requested.set(line.product_id, (requested.get(line.product_id) || 0) + quantity);
    }
  }

  for (const [productId, wanted] of requested) {
    const product = db.products.find((candidate) => candidate.id === productId);
    if (!product) {
      notices.push({ product_id: productId, message: 'Removed — this product no longer exists.' });
      continue;
    }

    const reason = blockedReason(product);
    if (reason) {
      notices.push({
        product_id: productId,
        product_name: product.name,
        reason,
        message: {
          recalled: 'Removed — this batch has been recalled by the manufacturer.',
          expired: 'Removed — the stock in the machine has passed its expiry date.',
          out_of_stock: 'Removed — this product is now out of stock.',
          inactive: 'Removed — this product is no longer offered.',
          prescription_only: 'Removed — this product requires a prescription.',
        }[reason],
      });
      continue;
    }

    const cap = maxPurchasable(product);
    const quantity = Math.min(wanted, cap);
    if (quantity < wanted) {
      notices.push({
        product_id: productId,
        product_name: product.name,
        message:
          cap === (product.max_qty_per_order ?? 3)
            ? `Quantity reduced to ${quantity} — at most ${cap} pack(s) per purchase.`
            : `Quantity reduced to ${quantity} — only ${cap} left in the machine.`,
      });
    }

    items.push({
      product_id: product.id,
      product_name: product.name,
      pack_size: product.pack_size,
      category: product.category,
      image_seed: product.image_seed,
      slot_code: product.slot_code,
      unit_price_paise: product.price_paise,
      gst_rate: product.gst_rate,
      quantity,
      line_total_paise: product.price_paise * quantity,
      max_purchasable: cap,
    });
  }

  const total = items.reduce((sum, item) => sum + item.line_total_paise, 0);
  const tax = items.reduce(
    (sum, item) => sum + gstComponent(item.line_total_paise, item.gst_rate),
    0,
  );

  return {
    items,
    notices,
    subtotal_paise: total - tax,
    tax_paise: tax,
    total_paise: total,
    item_count: items.reduce((count, item) => count + item.quantity, 0),
    currency: 'INR',
  };
}

// ---------------------------------------------------------------------------
// IDs
// ---------------------------------------------------------------------------

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no I/O/0/1 — read aloud at a machine

function token(length) {
  const bytes = crypto.randomBytes(length);
  let out = '';
  for (let i = 0; i < length; i += 1) out += ALPHABET[bytes[i] % ALPHABET.length];
  return out;
}

function newOrderId() {
  const today = new Date().toISOString().slice(0, 10).replace(/-/g, '');
  return `ORD-${today}-${token(4)}`;
}

const findOrder = (id) => db.orders.find((order) => order.id === id);

// ---------------------------------------------------------------------------
// SIMULATED payment
//
// A real integration would create a Razorpay QR here and confirm it from a
// signed webhook or by polling the provider's API. This demo generates a
// genuine UPI deep link so the QR is scannable, but nothing can confirm the
// payment automatically, so confirmation is an explicit simulated action.
// ---------------------------------------------------------------------------

function upiIntentUrl(order) {
  const params = new URLSearchParams({
    pa: UPI_VPA,
    pn: UPI_PAYEE,
    am: (order.total_paise / 100).toFixed(2),
    cu: 'INR',
    tn: `Order ${order.id}`,
  });
  return `upi://pay?${params.toString()}`;
}

// ---------------------------------------------------------------------------
// SIMULATED dispensing
//
// A real machine would send a command to a microcontroller over serial or MQTT
// and wait for a drop-sensor acknowledgement. This returns a result after a
// short delay, failing at SIM_FAILURE_RATE.
// ---------------------------------------------------------------------------

const DISPENSE_ERRORS = ['JAM', 'SLOT_EMPTY', 'MOTOR_FAULT', 'SENSOR_TIMEOUT'];

function simulateDispense(slotCode, quantity) {
  const failed = Math.random() < SIM_FAILURE_RATE;
  return {
    slot_code: slotCode,
    requested_quantity: quantity,
    dispensed_quantity: failed ? 0 : quantity,
    success: !failed,
    error_code: failed ? DISPENSE_ERRORS[Math.floor(Math.random() * DISPENSE_ERRORS.length)] : null,
    controller: 'simulated-v1',
    at: new Date().toISOString(),
  };
}

// ---------------------------------------------------------------------------
// HTTP
// ---------------------------------------------------------------------------

const app = express();
app.use(cors());
app.use(express.json());

// Stamp every response so the prototype can't be mistaken for a real system.
app.use((req, res, next) => {
  res.set('X-Demo-Mode', 'payment=simulated; dispenser=simulated; store=memory; admin_auth=none');
  next();
});

const ok = (res, body) => res.json(body);
const fail = (res, status, code, message, details) =>
  res.status(status).json({ error: { code, message, details } });

app.get('/api/health', (req, res) =>
  ok(res, {
    status: 'up',
    machine_id: MACHINE_ID,
    demo: true,
    payment: { provider: 'simulated_upi_qr', real_money: false },
    dispenser: { controller: 'simulated-v1', simulated: true },
    store: { driver: 'memory', persistent: false },
    admin_auth: false,
    support_phone: SUPPORT_PHONE,
    notices: { label: LABEL_NOTICE, data: DATA_DISCLAIMER },
  }),
);

// --- catalogue -------------------------------------------------------------

app.get('/api/categories', (req, res) => {
  const visible = db.products.filter((product) => !blockedReason(product));
  ok(
    res,
    CATEGORIES.map((category) => ({
      ...category,
      product_count: visible.filter((product) => product.category === category.key).length,
    })),
  );
});

app.get('/api/products', (req, res) => {
  const { category, q, sort } = req.query;

  // Anything not sellable is omitted from the storefront entirely.
  let rows = db.products.filter((product) => !blockedReason(product));

  if (category) rows = rows.filter((product) => product.category === category);
  if (q) {
    const needle = String(q).trim().toLowerCase();
    rows = rows.filter((product) =>
      [product.name, product.generic_name, product.sku, ...product.composition, ...product.uses]
        .join(' ')
        .toLowerCase()
        .includes(needle),
    );
  }

  const comparators = {
    price_asc: (a, b) => a.price_paise - b.price_paise,
    price_desc: (a, b) => b.price_paise - a.price_paise,
    name_desc: (a, b) => b.name.localeCompare(a.name),
  };
  rows.sort(comparators[sort] || ((a, b) => a.name.localeCompare(b.name)));

  ok(res, rows.map(toPublic));
});

app.get('/api/products/:id', (req, res) => {
  const product = db.products.find((candidate) => candidate.id === req.params.id);
  if (!product) return fail(res, 404, 'NOT_FOUND', 'Product not found.');
  return ok(res, toPublic(product));
});

// --- cart ------------------------------------------------------------------

app.post('/api/cart/validate', (req, res) => ok(res, priceCart(req.body?.items)));

// --- orders ----------------------------------------------------------------

app.post('/api/orders', async (req, res) => {
  const cart = priceCart(req.body?.items);
  if (cart.items.length === 0) {
    return fail(res, 409, 'EMPTY_CART', 'None of the selected items can be sold right now.', cart.notices);
  }

  const order = {
    id: newOrderId(),
    machine_id: MACHINE_ID,
    status: 'awaiting_payment',
    items: cart.items.map((item) => ({ ...item, dispensed_quantity: 0, item_status: 'pending' })),
    subtotal_paise: cart.subtotal_paise,
    tax_paise: cart.tax_paise,
    total_paise: cart.total_paise,
    currency: 'INR',
    customer_phone: (req.body?.customer_phone || '').trim() || null,
    collection_code: token(6),
    notices: cart.notices,
    dispense_log: [],
    refund_status: 'none',
    failure_reason: null,
    created_at: new Date().toISOString(),
    paid_at: null,
    dispensed_at: null,
  };

  // Reserve stock immediately so two sessions cannot buy the same last unit.
  for (const item of order.items) {
    const product = db.products.find((candidate) => candidate.id === item.product_id);
    product.stock -= item.quantity;
  }

  db.orders.push(order);

  const intent = upiIntentUrl(order);
  order.upi_intent_url = intent;
  order.qr_data_url = await QRCode.toDataURL(intent, { width: 320, margin: 1 });

  return ok(res, order);
});

app.get('/api/orders/:id', (req, res) => {
  const order = findOrder(req.params.id);
  if (!order) return fail(res, 404, 'NOT_FOUND', 'Order not found.');
  return ok(res, order);
});

app.post('/api/orders/:id/cancel', (req, res) => {
  const order = findOrder(req.params.id);
  if (!order) return fail(res, 404, 'NOT_FOUND', 'Order not found.');
  if (order.status !== 'awaiting_payment') {
    return fail(res, 409, 'CANNOT_CANCEL', `An order that is "${order.status}" cannot be cancelled.`);
  }

  // Put the reserved stock back.
  for (const item of order.items) {
    const product = db.products.find((candidate) => candidate.id === item.product_id);
    if (product) product.stock += item.quantity;
  }
  order.status = 'cancelled';
  return ok(res, order);
});

/**
 * SIMULATED PAYMENT CONFIRMATION — demo only.
 *
 * In a real deployment this endpoint would not exist. Payment would be
 * confirmed by a signed webhook from the payment provider, or by the server
 * polling the provider's API — never by a request from the browser.
 */
app.post('/api/orders/:id/simulate-payment', (req, res) => {
  const order = findOrder(req.params.id);
  if (!order) return fail(res, 404, 'NOT_FOUND', 'Order not found.');
  if (order.status !== 'awaiting_payment') {
    return fail(res, 409, 'NOT_AWAITING_PAYMENT', `Order is already "${order.status}".`);
  }

  const outcome = req.body?.outcome === 'failure' ? 'failure' : 'success';
  if (outcome === 'failure') {
    for (const item of order.items) {
      const product = db.products.find((candidate) => candidate.id === item.product_id);
      if (product) product.stock += item.quantity;
    }
    order.status = 'payment_failed';
    order.failure_reason = 'Payment was not completed.';
    return ok(res, order);
  }

  order.status = 'paid';
  order.paid_at = new Date().toISOString();
  order.payment = {
    simulated: true,
    method: 'upi_qr',
    reference: `SIMPAY-${token(8)}`,
    amount_paise: order.total_paise,
    confirmed_at: order.paid_at,
  };
  return ok(res, order);
});

/** Dispense. Refuses unless the server itself has marked the order paid. */
app.post('/api/orders/:id/dispense', async (req, res) => {
  const order = findOrder(req.params.id);
  if (!order) return fail(res, 404, 'NOT_FOUND', 'Order not found.');

  // Idempotent: a repeat call returns the existing result instead of
  // dispensing twice.
  if (['dispensed', 'partially_dispensed', 'dispense_failed'].includes(order.status)) {
    return ok(res, order);
  }
  if (order.status !== 'paid') {
    return fail(
      res,
      403,
      'PAYMENT_NOT_VERIFIED',
      'Payment has not been confirmed for this order. Dispensing is blocked.',
      { status: order.status },
    );
  }

  order.status = 'dispensing';

  for (const item of order.items) {
    const product = db.products.find((candidate) => candidate.id === item.product_id);

    // Last safety check before the motor turns: a recall or expiry that landed
    // after payment must still stop the product being handed over.
    if (product && ['recalled', 'expired'].includes(blockedReason(product) || '')) {
      item.item_status = 'failed';
      order.dispense_log.push({
        slot_code: item.slot_code,
        success: false,
        error_code: 'BLOCKED_BY_SAFETY_CHECK',
        requested_quantity: item.quantity,
        dispensed_quantity: 0,
        controller: 'simulated-v1',
        at: new Date().toISOString(),
      });
      continue;
    }

    // Simulated hardware latency.
    await new Promise((resolve) => setTimeout(resolve, 400));

    let result = simulateDispense(item.slot_code, item.quantity);
    order.dispense_log.push(result);

    // One automatic retry, as a real machine would do on a soft jam.
    if (!result.success) {
      await new Promise((resolve) => setTimeout(resolve, 400));
      result = { ...simulateDispense(item.slot_code, item.quantity), attempt: 2 };
      order.dispense_log.push(result);
    }

    item.dispensed_quantity = result.dispensed_quantity;
    item.item_status = result.success ? 'dispensed' : 'failed';

    if (!result.success && product) {
      product.stock += item.quantity; // nothing left the machine — return it
    }
  }

  const dispensed = order.items.filter((item) => item.item_status === 'dispensed');
  const failed = order.items.filter((item) => item.item_status === 'failed');

  if (failed.length === 0) {
    order.status = 'dispensed';
  } else if (dispensed.length === 0) {
    order.status = 'dispense_failed';
    order.failure_reason = 'The machine could not dispense your items.';
  } else {
    order.status = 'partially_dispensed';
    order.failure_reason = 'Some items could not be dispensed.';
  }

  // Refund exactly the value of what was not handed over.
  const refundPaise = failed.reduce((sum, item) => sum + item.line_total_paise, 0);
  if (refundPaise > 0) {
    order.refund_status = 'initiated';
    order.refund_amount_paise = refundPaise;
    order.refund_reference = `SIMRFND-${token(8)}`;
    for (const item of failed) item.item_status = 'refunded';
  }

  order.dispensed_at = new Date().toISOString();
  return ok(res, order);
});

// --- admin (NO AUTHENTICATION — demo only) ---------------------------------

app.get('/api/admin/products', (req, res) => {
  ok(
    res,
    db.products.map((product) => ({
      ...product,
      hidden_reason: blockedReason(product),
      is_visible_in_store: !blockedReason(product),
      days_to_expiry: daysToExpiry(product),
    })),
  );
});

app.post('/api/admin/products/:id', (req, res) => {
  const product = db.products.find((candidate) => candidate.id === req.params.id);
  if (!product) return fail(res, 404, 'NOT_FOUND', 'Product not found.');

  const allowed = [
    'name',
    'price_paise',
    'mrp_paise',
    'stock',
    'expiry_date',
    'batch_number',
    'slot_code',
    'is_active',
    'is_recalled',
    'recall_reason',
    'max_qty_per_order',
    'storage_instructions',
  ];
  for (const key of allowed) {
    if (req.body[key] !== undefined) product[key] = req.body[key];
  }
  if (product.is_recalled && !product.recall_reason) {
    product.recall_reason = 'Recalled by operator.';
  }
  if (!product.is_recalled) product.recall_reason = null;

  return ok(res, { ...product, hidden_reason: blockedReason(product) });
});

app.post('/api/admin/products/:id/restock', (req, res) => {
  const product = db.products.find((candidate) => candidate.id === req.params.id);
  if (!product) return fail(res, 404, 'NOT_FOUND', 'Product not found.');
  const quantity = Math.max(0, Number(req.body?.quantity) || 0);
  product.stock = Math.min(product.capacity, product.stock + quantity);
  return ok(res, product);
});

app.get('/api/admin/orders', (req, res) =>
  ok(res, [...db.orders].sort((a, b) => b.created_at.localeCompare(a.created_at))),
);

app.get('/api/admin/report', (req, res) => {
  const paid = db.orders.filter((order) => order.paid_at);
  const revenue = paid.reduce(
    (sum, order) => sum + order.total_paise - (order.refund_amount_paise || 0),
    0,
  );

  const unitsByProduct = new Map();
  for (const order of paid) {
    for (const item of order.items) {
      if (item.dispensed_quantity > 0) {
        const current = unitsByProduct.get(item.product_name) || 0;
        unitsByProduct.set(item.product_name, current + item.dispensed_quantity);
      }
    }
  }

  const attempts = db.orders.flatMap((order) => order.dispense_log);
  const failures = attempts.filter((attempt) => !attempt.success);

  ok(res, {
    orders_total: db.orders.length,
    orders_paid: paid.length,
    revenue_paise: revenue,
    refunds_paise: db.orders.reduce((sum, order) => sum + (order.refund_amount_paise || 0), 0),
    dispense_attempts: attempts.length,
    dispense_failures: failures.length,
    dispense_failure_rate:
      attempts.length === 0 ? 0 : Math.round((failures.length / attempts.length) * 100),
    top_products: [...unitsByProduct.entries()]
      .map(([name, units]) => ({ name, units }))
      .sort((a, b) => b.units - a.units)
      .slice(0, 5),
    alerts: {
      out_of_stock: db.products.filter((product) => product.stock === 0).length,
      low_stock: db.products.filter((product) => product.stock > 0 && product.stock <= 3).length,
      expired: db.products.filter((product) => isExpired(product)).length,
      expiring_soon: db.products.filter(
        (product) => !isExpired(product) && daysToExpiry(product) <= 30,
      ).length,
      recalled: db.products.filter((product) => product.is_recalled).length,
    },
  });
});

/** Demo convenience: put the machine back to its seeded state. */
app.post('/api/admin/reset', (req, res) => {
  seed();
  ok(res, { reset: true, products: db.products.length });
});

app.use('/api', (req, res) =>
  fail(res, 404, 'NOT_FOUND', `No route for ${req.method} ${req.originalUrl}`),
);

app.listen(PORT, () => {
  console.log(`\n  Smart Medical Vending Machine — DEMO backend`);
  console.log(`  http://localhost:${PORT}/api/health`);
  console.log(`  Payment: SIMULATED   Dispensing: SIMULATED   Store: in-memory (not persistent)`);
  console.log(`  Admin API is unauthenticated — do not expose beyond localhost.\n`);
});
